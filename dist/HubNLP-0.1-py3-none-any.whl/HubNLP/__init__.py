from .core import print_developer_info, print_library_tagline
