# HubNLP

HubNLP is a lightweight library for simplifying NLP tasks.

## Features
- Print developer info
- Display a library tagline

## Installation
```bash
pip install HubNLP
